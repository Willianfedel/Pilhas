/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.trabalho2;

import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;
/**
 *
 * @author willi
 */
public class Trabalho2 {

    public static void main(String[] args) {
    int senha;
    String nome;
    int anoNascimento;

    public Cliente(int senha, String nome, int anoNascimento) {
        this.senha = senha;
        this.nome = nome;
        this.anoNascimento = anoNascimento;
    }
}

public class FilaDeAtendimento {
    public static void main(String[] args) {
        Queue<Cliente> filaPrioritaria = new LinkedList<>();
        Queue<Cliente> filaNormal = new LinkedList<>();
        Scanner scanner = new Scanner(System.in);

        int opcao;

        do {
            System.out.println("Menu:");
            System.out.println("1 - Adicionar cliente");
            System.out.println("2 - Chamar cliente");
            System.out.println("0 - Sair");
            System.out.print("Escolha uma opção: ");
            opcao = scanner.nextInt();

            switch (opcao) {
                case 1:
                    System.out.print("Informe o nome do cliente: ");
                    String nome = scanner.next();
                    System.out.print("Informe o ano de nascimento do cliente: ");
                    int anoNascimento = scanner.nextInt();
                    System.out.print("Informe a senha do cliente: ");
                    int senha = scanner.nextInt();
                    Cliente cliente = new Cliente(senha, nome, anoNascimento);
                    if (cliente.anoNascimento <= 1956) {
                        filaPrioritaria.add(cliente);
                        System.out.println("Cliente " + cliente.nome + " adicionado à fila prioritária.");
                    } else {
                        filaNormal.add(cliente);
                        System.out.println("Cliente " + cliente.nome + " adicionado à fila normal.");
                    }
                    break;
                case 2:
                    if (!filaPrioritaria.isEmpty()) {
                        atenderCliente(filaPrioritaria);
                    } else if (!filaNormal.isEmpty()) {
                        atenderCliente(filaNormal);
                    } else {
                        System.out.println("Não há clientes para atender.");
                    }
                    break;
                case 0:
                    System.out.println("Encerrando o programa.");
                    break;
                default:
                    System.out.println("Opção inválida. Tente novamente.");
            }

        } while (opcao != 0);

        scanner.close();
    }

    private static void atenderCliente(Queue<Cliente> fila) {
        Cliente clienteAtendido = fila.poll();
        System.out.println("Cliente " + clienteAtendido.nome + " atendido.");
    }
}