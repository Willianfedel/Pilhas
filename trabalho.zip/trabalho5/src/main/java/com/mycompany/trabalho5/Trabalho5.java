/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.trabalho5;

import java.util.Scanner;
import java.util.Stack;
/**
 *
 * @author willi
 */
public class Trabalho5 {

    public static void main(String[] args) {
   int codProduto;
    String descricao;
    String dataEntrada;
    String ufOrigem;
    String ufDestino;

    public Produto(int codProduto, String descricao, String dataEntrada, String ufOrigem, String ufDestino) {
        this.codProduto = codProduto;
        this.descricao = descricao;
        this.dataEntrada = dataEntrada;
        this.ufOrigem = ufOrigem;
        this.ufDestino = ufDestino;
    }

    @Override
    public String toString() {
        return "Produto{" +
                "codProduto=" + codProduto +
                ", descricao='" + descricao + '\'' +
                ", dataEntrada='" + dataEntrada + '\'' +
                ", ufOrigem='" + ufOrigem + '\'' +
                ", ufDestino='" + ufDestino + '\'' +
                '}';
    }
}

public class ControleDeDeposito {
    public static void main(String[] args) {
        Stack<Produto>[] pilhasDeCaixas = new Stack[5];
        for (int i = 0; i < pilhasDeCaixas.length; i++) {
            pilhasDeCaixas[i] = new Stack<>();
        }

        Scanner scanner = new Scanner(System.in);

        int opcao;
        int pilhaSelecionada;

        do {
            System.out.println("Menu:");
            System.out.println("1 - Adicionar caixa");
            System.out.println("2 - Retirar caixa");
            System.out.println("0 - Sair");
            System.out.print("Escolha uma opção: ");
            opcao = scanner.nextInt();

            switch (opcao) {
                case 1:
                    System.out.print("Informe a pilha (0-4) para adicionar a caixa: ");
                    pilhaSelecionada = scanner.nextInt();
                    if (pilhaSelecionada >= 0 && pilhaSelecionada < 5) {
                        adicionarCaixa(pilhasDeCaixas[pilhaSelecionada], scanner);
                    } else {
                        System.out.println("Pilha selecionada inválida.");
                    }
                    break;
                case 2:
                    System.out.print("Informe a pilha (0-4) para retirar a caixa: ");
                    pilhaSelecionada = scanner.nextInt();
                    if (pilhaSelecionada >= 0 && pilhaSelecionada < 5) {
                        retirarCaixa(pilhasDeCaixas[pilhaSelecionada]);
                    } else {
                        System.out.println("Pilha selecionada inválida.");
                    }
                    break;
                case 0:
                    System.out.println("Encerrando o programa.");
                    break;
                default:
                    System.out.println("Opção inválida. Tente novamente.");
            }

            System.out.println("Posições atuais das pilhas:");
            listarPilhas(pilhasDeCaixas);

        } while (opcao != 0);

        scanner.close();
    }

    private static void adicionarCaixa(Stack<Produto> pilha, Scanner scanner) {
        if (pilha.size() >= 10) {
            System.out.println("A pilha está cheia. Não é possível adicionar mais caixas.");
        } else {
            System.out.print("Informe o código do produto: ");
            int codProduto = scanner.nextInt();
            System.out.print("Informe a descrição do produto: ");
            String descricao = scanner.next();
            System.out.print("Informe a data de entrada do produto: ");
            String dataEntrada = scanner.next();
            System.out.print("Informe o UF de origem do produto: ");
            String ufOrigem = scanner.next();
            System.out.print("Informe o UF de destino do produto: ");
            String ufDestino = scanner.next();
            Produto produto = new Produto(codProduto, descricao, dataEntrada, ufOrigem, ufDestino);
            pilha.push(produto);
            System.out.println("Caixa adicionada à pilha " + pilha);
        }
    }

    private static void retirarCaixa(Stack<Produto> pilha) {
        if (!pilha.isEmpty()) {
            Produto produtoRetirado = pilha.pop();
            System.out.println("Produto despachado da pilha " + pilha + ": " + produtoRetirado);
        } else {
            System.out.println("A pilha de caixas está vazia.");
        }
    }

    private static void listarPilhas(Stack<Produto>[] pilhas) {
        for (int i = 0; i < pilhas.length; i++) {
            System.out.println("Pilha " + i + ":");
            if (!pilhas[i].isEmpty()) {
                for (Produto produto : pilhas[i]) {
                    System.out.println(produto);
                }
            } else {
                System.out.println("A pilha de caixas está vazia.");
            }
        }
    }
}
