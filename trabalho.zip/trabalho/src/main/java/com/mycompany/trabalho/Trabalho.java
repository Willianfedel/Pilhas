/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.trabalho;

import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;
/**
 *
 * @author willi
 */
public class Trabalho {

    public static void main(String[] args) {
        Queue<String> fila = new LinkedList<>();
        Scanner scanner = new Scanner(System.in);
        
        int opcao;
        
        do {
            System.out.println("Menu:");
            System.out.println("1 - Adicionar paciente");
            System.out.println("2 - Chamar próximo paciente");
            System.out.println("0 - Sair");
            System.out.print("Escolha uma opção: ");
            opcao = scanner.nextInt();
            
            switch (opcao) {
                case 1:
                    System.out.print("Informe o nome do paciente: ");
                    scanner.nextLine(); // Limpar o buffer do teclado
                    String nome = scanner.nextLine();
                    fila.add(nome);
                    System.out.println("Paciente " + nome + " adicionado à fila.");
                    break;
                case 2:
                    if (!fila.isEmpty()) {
                        String proximoPaciente = fila.poll();
                        System.out.println("Próximo paciente: " + proximoPaciente);
                    } else {
                        System.out.println("Não há pacientes na fila.");
                    }
                    break;
                case 0:
                    System.out.println("Encerrando o programa.");
                    break;
                default:
                    System.out.println("Opção inválida. Tente novamente.");
            }
            
        } while (opcao != 0);
        
        scanner.close();
    }
}
    