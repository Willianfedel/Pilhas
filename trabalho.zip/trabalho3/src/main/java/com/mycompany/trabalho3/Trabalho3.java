/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.trabalho3;
import java.util.Scanner;
import java.util.Stack;
/**
 *
 * @author willi
 */
public class Trabalho3 {

    public static void main(String[] args) {
    String titulo;
    String autor;

    public Trabalho3(String titulo, String autor) {
        this.titulo = titulo;
        this.autor = autor;
    }

    @Override
    public String toString() {
        return "Livro{" +
                "titulo='" + titulo + '\'' +
                ", autor='" + autor + '\'' +
                '}';
    }
}

public class ControleDePilha {
    public static void main(String[] args) {
        Stack<Livro> pilhaDeLivros = new Stack<>();
        Scanner scanner = new Scanner(System.in);

        int opcao;

        do {
            System.out.println("Menu:");
            System.out.println("1 - Adicionar livro");
            System.out.println("2 - Listar livros");
            System.out.println("3 - Retirar livro");
            System.out.println("0 - Sair");
            System.out.print("Escolha uma opção: ");
            opcao = scanner.nextInt();

            switch (opcao) {
                case 1:
                    System.out.print("Informe o título do livro: ");
                    String titulo = scanner.next();
                    System.out.print("Informe o autor do livro: ");
                    String autor = scanner.next();
                    Livro livro = new Livro(titulo, autor);
                    pilhaDeLivros.push(livro);
                    System.out.println("Livro adicionado à pilha.");
                    break;
                case 2:
                    listarLivros(pilhaDeLivros);
                    break;
                case 3:
                    if (!pilhaDeLivros.isEmpty()) {
                        Livro livroRetirado = pilhaDeLivros.pop();
                        System.out.println("Livro retirado da pilha: " + livroRetirado);
                    } else {
                        System.out.println("A pilha de livros está vazia.");
                    }
                    break;
                case 0:
                    System.out.println("Encerrando o programa.");
                    break;
                default:
                    System.out.println("Opção inválida. Tente novamente.");
            }

        } while (opcao != 0);

        scanner.close();
    }

    private static void listarLivros(Stack<Livro> pilha) {
        if (!pilha.isEmpty()) {
            System.out.println("Livros na pilha:");
            for (Livro livro : pilha) {
                System.out.println(livro);
            }
        } else {
            System.out.println("A pilha de livros está vazia.");
        }
    }
}